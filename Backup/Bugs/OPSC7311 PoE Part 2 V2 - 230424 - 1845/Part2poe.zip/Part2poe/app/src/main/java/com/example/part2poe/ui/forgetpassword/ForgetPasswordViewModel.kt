package com.example.part2poe.ui.forgetpassword

import androidx.lifecycle.ViewModel

class ForgetPasswordViewModel : ViewModel()  {
}