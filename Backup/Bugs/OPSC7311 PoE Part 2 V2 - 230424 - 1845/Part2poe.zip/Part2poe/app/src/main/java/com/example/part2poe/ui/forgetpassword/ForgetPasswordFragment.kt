package com.example.part2poe.ui.forgetpassword

import androidx.fragment.app.Fragment

class ForgetPasswordFragment : Fragment() {
}